
"""
Created on Mon Jul 04 13:15:00 2022

@author: timtic
"""

###############################################################################
###############################################################################
#                    Importing required modules
###############################################################################
###############################################################################
import numpy as np
import struct
"""
#------------------------------------------------------------------------------
# tkinter for building GUIs 
#------------------------------------------------------------------------------"""
import tkinter as tk 
from   tkinter import ttk                           # Python 3
from   tkinter import *                             # Python 3
from   tkinter import messagebox                    # Python 3
from   tkinter import Menu                          # Python 3
from   tkinter import filedialog                    # Python 3
from   tkinter.scrolledtext  import ScrolledText    # Python 3
#------------------------------------------------------------------------------
# matplotlib related modules for graphics
#------------------------------------------------------------------------------   
from matplotlib.backends.backend_tkagg import (FigureCanvasTkAgg, NavigationToolbar2Tk)
#------------------------------------------------------------------------------
# Implement the default Matplotlib key bindings.
#------------------------------------------------------------------------------
from matplotlib.backend_bases import key_press_handler
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
"""
#------------------------------------------------------------------------------
# time for timed events, serial for serial
# communication of Arduino with the PC. The 
# serial requires the installation of pyserial
# on the operating PC.
#------------------------------------------------------------------------------"""   
import time
import serial
#------------------------------------------------------------------------------
from datetime import datetime        # import datetome for checking recent cal file     
#------------------------------------------------------------------------------
#------------------------------------------------------------------------------     




def PotentiostatScript_CA():
    #print(__name__)
    global CalData
    CalData = 0
    global Zero_IDX_E
    global Zero_IDX_I
    Zero_IDX_E = 13250
    Zero_IDX_I = 13250
    try: 
        CalFile    = datetime.today().strftime('CALIBRATION\%Y_%m_%d_Cal.txt')
        CalData    = np.genfromtxt(CalFile , skip_header = 0, skip_footer = 1)
        Neg_IDX_E  = np.average(CalData[CalData[::,1]==1,3])
        Pos_IDX_E  = np.average(CalData[CalData[::,1]==2,3])
        Neg_IDX_I  = np.average(CalData[CalData[::,1]==1,4])
        Pos_IDX_I  = np.average(CalData[CalData[::,1]==2,4])
        Zero_IDX_E = int(0.5*(Neg_IDX_E + Pos_IDX_E))
        Zero_IDX_I = int(0.5*(Neg_IDX_I + Pos_IDX_I))
    
    except:
            messagebox.showwarning(title="No Recent Calibration found!", message="You did not provide a recent calibration file!\n Your data might be incorrect.")
            txt_filename = ""


    global running
    running       = False              # boolean for running the script deactivated
    Initiate_Plot = True               # For first setup of a plot
    Refresh_Count = 0                  # Count to a certain number before refreshing plot
    global PlotType
    PlotType      = 1
    global Data_Collected
    Data_Collected = False
    ###############################################################################
    #    Define plotting options to make the plot look cool :)
    ###############################################################################
    font = {'family': 'Times New Roman', 'color':  'black','weight': 'normal','size': 15,}
    plt.rcParams['mathtext.fontset'] = 'dejavuserif'
    plt.rcParams['font.sans-serif'] = ['Times new Roman']
    ###############################################################################
    ###############################################################################
    ###############################################################################
    # The following function asks for a filename, where the data will be stored
    ###############################################################################
    def AskSaveFile_AndStart_CA():
        try:
            txt_filename = filedialog.asksaveasfile(defaultextension='.txt').name #öffnet fenster um nach speicherort zu fragen
        except:
            messagebox.showwarning(title="No File selected!", message="You did not select a file to save to!")
            txt_filename = ""
        else:
            global outfile_CA_Data
            outfile_CA_Data = open(txt_filename, 'w')
            StartRead_CA()
    
    
    ###############################################################################
    # The following function  will find available Arduino-ports which are able for 
    # serial communication. This function wil be embedded into a GUI later on.
    ###############################################################################
    def FindPorts():
        ports = ['COM%s' % (i+1) for i in range(256)]
        result = []
        for port in ports:
            try:
                s = serial.Serial(port)
                s.close()
                result.append(port)
            except (OSError, serial.SerialException):
                pass
        return result
    ###############################################################################
    # The following function is used to refresh the portlist (function callback)
    ###############################################################################
    def Portlist_Refresh():
        global portsl
        portsl = FindPorts()
    ###############################################################################
    # The following functionwill find available Arduino-ports which are able for 
    # serial communication. This function wil be embedded into a GUI later on.
    ###############################################################################
    
    def StartSerial():
        global arduino                                                                           # TT comment: Initiate the global variable arduino
        Write_Output_CA("Serial communication at Port %s established successfully" %portList.get())
        try:
            arduino = serial.Serial(portList.get(), baudrate = 115200, timeout=.1) # TT comment: define the communication with the Arduino
            time.sleep(2)
        except:
            messagebox.showerror(title="Serial Communication failed!", 
                                 message="Unable to communicate with selected Port or no Port selected")
        else:
            randfloat  = 11.01                                      # construct a random float to send
            SEND_BYTES = b'\x44\x66' + struct.pack('f', randfloat)  # third entry of stuff to send is the packed version of the generated float
            arduino.write(SEND_BYTES)                               # Here, the bytes are send to the arduino
            time.sleep(2)                                           # sleep for 2 seconds
            SER_OUT_1  = arduino.readline()[:-2]                    # since Arduino returns the suff with println, at which end is always \r\n, skip the last to, to get what matters
            SER_OUT_2  = arduino.readline()[:-2]                    # Read the float which was send to Arduino, analogue, skip the last two entries
            if (SER_OUT_1 == SEND_BYTES) & (float(SER_OUT_2) == np.round(randfloat, decimals = 2)):
                pass                                                # pass the loop, if connection is established
            else:
                messagebox.showwarning(title="Serial Connection Corrupted!", 
                                       message="It seems like the data recieved over Serial is corrupted!")
    ###############################################################################
    ###############################################################################
    
    
    def Set_CA_Params():
        global ReadResist
        try:
            E_1          = float(E_1_Eingabe.get())
            E_2          = float(E_2_Eingabe.get())
            E_3          = float(E_3_Eingabe.get())
            E_4          = float(E_4_Eingabe.get())
            E_5          = float(E_5_Eingabe.get())
            t_1          = (1e3)*float(t_1_Eingabe.get())  # Transmission in ms
            t_2          = (1e3)*float(t_2_Eingabe.get())  # Transmission in ms
            t_3          = (1e3)*float(t_3_Eingabe.get())  # Transmission in ms
            t_4          = (1e3)*float(t_4_Eingabe.get())  # Transmission in ms
            t_5          = (1e3)*float(t_5_Eingabe.get())  # Transmission in ms
            Repetitions  = float(Repetitions_Eingabe.get())
            ReadResist   = float(R_read_Eingabe.get())
            #---------------------------------------------------
            # Prepare sending the Info to Arduino
            #---------------------------------------------------
            SEND_E_1   = b'\x12' + b'\x17' + struct.pack('f', E_1)          # b'\x12' means modify CA params. Rest, look in Arduino script
            SEND_E_2   = b'\x12' + b'\x18' + struct.pack('f', E_2)          # b'\x12' means modify CA params. Rest, look in Arduino script
            SEND_E_3   = b'\x12' + b'\x19' + struct.pack('f', E_3)          # b'\x12' means modify CA params. Rest, look in Arduino script
            SEND_E_4   = b'\x12' + b'\x20' + struct.pack('f', E_4)          # b'\x12' means modify CA params. Rest, look in Arduino script
            SEND_E_5   = b'\x12' + b'\x21' + struct.pack('f', E_5)          # b'\x12' means modify CA params. Rest, look in Arduino script
            SEND_t_1   = b'\x12' + b'\x22' + struct.pack('f', t_1)          # b'\x12' means modify CA params. Rest, look in Arduino script
            SEND_t_2   = b'\x12' + b'\x23' + struct.pack('f', t_2)          # b'\x12' means modify CA params. Rest, look in Arduino script
            SEND_t_3   = b'\x12' + b'\x24' + struct.pack('f', t_3)          # b'\x12' means modify CA params. Rest, look in Arduino script
            SEND_t_4   = b'\x12' + b'\x25' + struct.pack('f', t_4)          # b'\x12' means modify CA params. Rest, look in Arduino script
            SEND_t_5   = b'\x12' + b'\x26' + struct.pack('f', t_5)          # b'\x12' means modify CA params. Rest, look in Arduino script
            SEND_REP   = b'\x12' + b'\x27' + struct.pack('f', Repetitions)  # b'\x12' means modify CA params. Rest, look in Arduino script
            
            #---------------------------------------------------
            # Start sending the Info to Arduino
            #---------------------------------------------------
            arduino.write(SEND_E_1)
            time.sleep(2) 
            arduino.write(SEND_E_2)
            time.sleep(2) 
            arduino.write(SEND_E_3)
            time.sleep(2) 
            arduino.write(SEND_E_4)
            time.sleep(2) 
            arduino.write(SEND_E_5)
            time.sleep(2) 
            arduino.write(SEND_t_1)
            time.sleep(2) 
            arduino.write(SEND_t_2)
            time.sleep(2) 
            arduino.write(SEND_t_3)
            time.sleep(2) 
            arduino.write(SEND_t_4)
            time.sleep(2) 
            arduino.write(SEND_t_5)
            time.sleep(2) 
            arduino.write(SEND_REP)
            time.sleep(2) 
            #-----------------------------------------------------
            # In case of successful transmission, print statement   
            #-----------------------------------------------------
            Write_Output_CA("\n Data transmission complete :) \n---------------------------------------------")
        except:
            messagebox.showerror(title="Incomplete Parameters!", 
                                 message="All inputs have to be filled out in order to run a CV!")
        
    ###############################################################################
    ###############################################################################
    
    
    def Get_CA_Params():
        '''
        # the readline reads the already converted input,         
        # the[:-2] skips the last \r\n of println in Arduino. 
        # The float converts the output into a float.
        '''
        #======================================
        # Reading back the initial potential 
        #======================================
        GETTING_COMMAND_BYTES  = b'\x13\x00\x00\x00\x00\x00'     
        arduino.write(GETTING_COMMAND_BYTES)
        
        global E_1_Readback         ;         global t_1_Readback 
        global E_2_Readback         ;         global t_2_Readback 
        global E_3_Readback         ;         global t_3_Readback 
        global E_4_Readback         ;         global t_4_Readback 
        global E_5_Readback         ;         global t_5_Readback 
        global Repetitions_Readback
        
        time.sleep(2) 
        E_1_Readback         = float(arduino.readline()[:-2])  
        E_2_Readback         = float(arduino.readline()[:-2]) 
        E_3_Readback         = float(arduino.readline()[:-2]) 
        E_4_Readback         = float(arduino.readline()[:-2]) 
        E_5_Readback         = float(arduino.readline()[:-2])
        t_1_Readback         = (1e-3)*float(arduino.readline()[:-2])  
        t_2_Readback         = (1e-3)*float(arduino.readline()[:-2]) 
        t_3_Readback         = (1e-3)*float(arduino.readline()[:-2]) 
        t_4_Readback         = (1e-3)*float(arduino.readline()[:-2]) 
        t_5_Readback         = (1e-3)*float(arduino.readline()[:-2])      
        Repetitions_Readback = float(arduino.readline()[:-2])

        Write_Output_CA("The following Parameters were set! \n")   
        Write_Output_CA("E1 \t= \t %s V vs. Re" %E_1_Readback)  
        Write_Output_CA("E2 \t= \t %s V vs. Re" %E_2_Readback)  
        Write_Output_CA("E3 \t= \t %s V vs. Re" %E_3_Readback)  
        Write_Output_CA("E4 \t= \t %s V vs. Re" %E_4_Readback)  
        Write_Output_CA("E5 \t= \t %s V vs. Re" %E_5_Readback)  
        Write_Output_CA("t1 \t= \t %s s" %t_1_Readback)  
        Write_Output_CA("t2 \t= \t %s s" %t_2_Readback)  
        Write_Output_CA("t3 \t= \t %s s" %t_3_Readback)  
        Write_Output_CA("t4 \t= \t %s s" %t_4_Readback)  
        Write_Output_CA("t5 \t= \t %s s" %t_5_Readback)   
        Write_Output_CA("Repetitions \t = \t %s " %Repetitions_Readback)  

        
    ###############################################################################
    ###############################################################################
    
    def StartRead_CA():
        Get_CA_Params()
        global running
        global file_error
        global Storage_Array
        global UpCounter
        global Data_Collected
        UpCounter = 0
        Storage_Array = np.zeros((1,5))
        
        SEND_BYTES = b'\x14\x00\x00\x00\x00\x00'
        arduino.write(SEND_BYTES)
        time.sleep(3)
        
        Starter = arduino.readline()[:-2]
        while Starter != b'10101010':          # proceed only, if Arduino tells that conditioning-loop is done by sending b'101010'
            time.sleep(0.001)                  # Wait for one millisecond before trying again  
            Starter = arduino.readline()[:-2]  # read again and enter while loop again (if not fulfilled)
        
        running         = True
        file_error      = True
        Data_Collected  = True
        Write_Output_CA("\n Preparing CA completed.\n\n") 
        Write_Output_CA("Loop.No.\t Step.No.\t t/ms\t E/V\t I/mA\n")
        
        
    ###############################################################################
    ############################################################################### 
    
    def Stop_CA():
        global running
        global file_error
        file_error = True
        running = False
        StopReadBackup_CA()
        Write_Output_CA("\n Status: Measurment was manually stopped by User.\n") 
        Portlist_Refresh()
    
    ###############################################################################
    ###############################################################################
      
    def StopReadSuccess_CA():
        global running
        global file_error
        file_error = False
        running = False
        #==================================================================
        #   Write output in the output-txt file
        #==================================================================
        outfile_CA_Data.write("Input Data Chronoamperometry\n\n")
        outfile_CA_Data.write("E_1 vs. Ref in V \t %s" %E_1_Readback)
        outfile_CA_Data.write("\n")
        outfile_CA_Data.write("E_2 vs. Ref in V \t %s" %E_2_Readback)
        outfile_CA_Data.write("\n")
        outfile_CA_Data.write("E_3 vs. Ref in V \t %s" %E_3_Readback)
        outfile_CA_Data.write("\n")
        outfile_CA_Data.write("E_4 vs. Ref in V \t %s" %E_4_Readback)
        outfile_CA_Data.write("\n")
        outfile_CA_Data.write("E_5 vs. Ref in V \t %s" %E_5_Readback)
        outfile_CA_Data.write("\n")
        outfile_CA_Data.write("t_1 in s \t %s" %t_1_Readback)
        outfile_CA_Data.write("\n")
        outfile_CA_Data.write("t_2 in s \t %s" %t_1_Readback)
        outfile_CA_Data.write("\n")
        outfile_CA_Data.write("t_3 in s \t %s" %t_1_Readback)
        outfile_CA_Data.write("\n")
        outfile_CA_Data.write("t_4 in s \t %s" %t_1_Readback)
        outfile_CA_Data.write("\n")
        outfile_CA_Data.write("t_5 in s \t %s" %t_1_Readback)
        outfile_CA_Data.write("\n")
        outfile_CA_Data.write("Repetitions \t = \t %s " %Repetitions_Readback)
        outfile_CA_Data.write("\n\n")
        outfile_CA_Data.write("======================================================\n\n")
        outfile_CA_Data.write("Main_Step\tSub_Step\ttime in ms\tE_WE_vs_RE in V\tI in mA\n")
        for i in range(len(Storage_Array[::,0])-1):
            outfile_CA_Data.write(str(Storage_Array[i+1,0]))
            outfile_CA_Data.write("\t")
            outfile_CA_Data.write(str(Storage_Array[i+1,1]))
            outfile_CA_Data.write("\t")
            outfile_CA_Data.write(str(0.001*Storage_Array[i+1,2]))
            outfile_CA_Data.write("\t")
            outfile_CA_Data.write(str(-0.000249*(Storage_Array[i+1,3]-Zero_IDX_E)))
            outfile_CA_Data.write("\t")
            outfile_CA_Data.write(str(-0.12452*(Storage_Array[i+1,4]-Zero_IDX_I)/ReadResist))
            outfile_CA_Data.write("\n")
        outfile_CA_Data.close()
        #==================================================================
        # write in output window that the measurement has terminated 
        #==================================================================  
        Write_Output_CA("\n Status: Measurment terminated successfully.\n") 
        try:
            arduino.close() 
            Write_Output("\n Status: Serial port closed...\n") 
        except:
            pass
        
        
    def StopReadBackup_CA():
        global running
        global file_error
        file_error = False
        running = False
        #==================================================================
        #   Write output in the output-txt file
        #==================================================================
        outfile_CA_Data.write("Input Data Chronoamperometry\n\n")
        outfile_CA_Data.write("E_1 vs. Ref in V \t %s" %E_1_Readback)
        outfile_CA_Data.write("\n")
        outfile_CA_Data.write("E_2 vs. Ref in V \t %s" %E_2_Readback)
        outfile_CA_Data.write("\n")
        outfile_CA_Data.write("E_3 vs. Ref in V \t %s" %E_3_Readback)
        outfile_CA_Data.write("\n")
        outfile_CA_Data.write("E_4 vs. Ref in V \t %s" %E_4_Readback)
        outfile_CA_Data.write("\n")
        outfile_CA_Data.write("E_5 vs. Ref in V \t %s" %E_5_Readback)
        outfile_CA_Data.write("\n")
        outfile_CA_Data.write("t_1 in s \t %s" %t_1_Readback)
        outfile_CA_Data.write("\n")
        outfile_CA_Data.write("t_2 in s \t %s" %t_2_Readback)
        outfile_CA_Data.write("\n")
        outfile_CA_Data.write("t_3 in s \t %s" %t_3_Readback)
        outfile_CA_Data.write("\n")
        outfile_CA_Data.write("t_4 in s \t %s" %t_4_Readback)
        outfile_CA_Data.write("\n")
        outfile_CA_Data.write("t_5 in s \t %s" %t_5_Readback)
        outfile_CA_Data.write("\n")
        outfile_CA_Data.write("Repetitions \t = \t %s " %Repetitions_Readback)
        outfile_CA_Data.write("\n\n")
        outfile_CA_Data.write("======================================================\n\n")
        outfile_CA_Data.write("Main_Step\tSub_Step\ttime in ms\tE_WE_vs_RE in V\tI in mA\n")
        for i in range(len(Storage_Array[::,0])-1):
            outfile_CA_Data.write(str(Storage_Array[i+1,0]))
            outfile_CA_Data.write("\t")
            outfile_CA_Data.write(str(Storage_Array[i+1,1]))
            outfile_CA_Data.write("\t")
            outfile_CA_Data.write(str(0.001*Storage_Array[i+1,2]))
            outfile_CA_Data.write("\t")
            outfile_CA_Data.write(str(-0.000249*(Storage_Array[i+1,3]-Zero_IDX_E)))
            outfile_CA_Data.write("\t")
            outfile_CA_Data.write(str(-0.12452*(Storage_Array[i+1,4]-Zero_IDX_I)/ReadResist))
            outfile_CA_Data.write("\n")
        outfile_CA_Data.close()
        #==================================================================
        # write in output window that the measurement has terminated 
        #==================================================================  
        Write_Output_CA("\n Status: Measurment got terminated by some reason...\n") 
        try:
            arduino.close() 
            Write_Output("\n Status: Serial port closed...\n") 
        except:
            pass
       
    
    ###############################################################################
    # The following function will exit GUI cleanly.
    ###############################################################################
    def _quit():
        PotentiostatWindow.quit()
        PotentiostatWindow.destroy()
    ###############################################################################
    ############################################################################### 
    def Write_Output_CA(Text): 
        Output_text.insert(INSERT, "%s \n" %Text )
    ###############################################################################
    ###############################################################################   
    def Write_Data_CA(DataToWrite):
        Output_text.insert(INSERT, "%s \t"   %DataToWrite[0]   )
        Output_text.insert(INSERT, "%s \t"   %DataToWrite[1]   )
        Output_text.insert(INSERT, "%.f \t"  %DataToWrite[2]   )
        Output_text.insert(INSERT, "%.4f \t" %(-0.000249*(DataToWrite[3]-Zero_IDX_E))   )
        Output_text.insert(INSERT, "%.4f \n" %(-0.12452*(DataToWrite[4]-Zero_IDX_I)/ReadResist)   )
    ###############################################################################
    #    The following function takes an array and reduces it by its first comuln 
    #    indices by averaging equal ones. This is what BioLogic does when it says
    #    average over n-percent of the step. Here, we just have (around 4 points).
    ###############################################################################   
    def Arraycondenser(ARRAY):
        NLB   = 0
        Out   = np.zeros(len(ARRAY[0,1::]))
        for i in range(len(ARRAY[::,0])-1):
            if ARRAY[i+1,0] != ARRAY[i,0]:
                B   = np.mean(ARRAY[NLB:i+1,1::], axis = 0)
                B[0] = ARRAY[i,1]
                Out = np.vstack([Out,B])        
                NLB = i+1
        return Out[1::,::]
        
        
    ###############################################################################
    #    Marius-functions reduced
    ###############################################################################   
    def Serial_Looper():          # This function will be called in a loop back and forth with the main_loop of the GUI to update the output
        global running
        global file_error
        global data 
        global Storage_Array
        global UpCounter
        if running == True:
            try:
                data = arduino.readline()[:-2]
                if data:
                    if data != b'999999':   # As soon as the Arduino sends this, the measurement is done
                        DECODED       = np.array(data.decode("utf-8").split('\t'))
                        DECODED_FLOAT = DECODED.astype(np.float)
                        #print(DECODED_FLOAT)
                        Write_Data_CA(DECODED_FLOAT)   
                        Storage_Array = np.vstack([Storage_Array, DECODED_FLOAT])
                        UpCounter += 1
                        if UpCounter == 10:
                            Array_to_Plot = Storage_Array
                            PlotCA(InputArray = Array_to_Plot)
                            #------------------------------------------------------
                            #For plotting the real RAW data (so EVERY point)
                            #------------------------------------------------------
                            #PlotCV(InputArray = Storage_Array[1::,1::])
                            #------------------------------------------------------
                            UpCounter = 0
                    if data == b'999999':
                        StopReadSuccess_CA()
            except:
                StopReadBackup_CA()
                messagebox.showerror(title="Communication NOT started or broken!", message="It seems like communication was not started\nor is broken. Please Start Serial Communication first!")
                running = False
        PotentiostatWindow.after(1, Serial_Looper)
        
        
    def Plot_Spacer():
        global PlotType
        fig = Figure(figsize = (6.5,4.5), dpi = 68)
        plot1 = fig.add_subplot(111)
        x = np.array([0])
        y = np.array([0])
        plot1.plot((x,y), linewidth = 0)                     # 3300/26500 = 0.12452   
        plot1.set_xlabel("$t$ in s", fontsize = 13)
        plot1.set_ylabel("$I$ in mA", fontsize = 13, color = 'blue')
        plot1.set_xticks([-0.2, -0.1, 0.0, 0.1, 0.2])
        plot1.set_yticks([-0.2, -0.1, 0.0, 0.1, 0.2])
        plot1.set_ylim(-0.25,0.25)
        plot1.grid(which='both', linestyle = '--')
        plot1.tick_params(direction = 'in', length=4, width=0.5, colors='k', labelsize = 13)
        plot2 = plot1.twinx()
        plot2.plot((x,y), linewidth = 0)     
        plot2.set_ylabel("$E$ vs. RE in V", fontsize = 13, color = 'red')
        plot2.grid(which='both', linestyle = '--')
        plot2.set_xticks([-0.2, -0.1, 0.0, 0.1, 0.2])
        plot2.set_yticks([-0.2, -0.1, 0.0, 0.1, 0.2])
        plot2.set_xlim(-0.25,0.25)
        plot2.set_ylim(-0.25,0.25)
        plot2.tick_params(direction = 'in', length=4, width=0.5, colors='k', labelsize = 13)
        canvas = FigureCanvasTkAgg(fig, PotentiostatWindow)  
        canvas.draw()
        canvas.get_tk_widget().place(x = 325, y = 10)
        
    
    def PlotCA(InputArray):
        fig = Figure(figsize = (6.5,4.5), dpi = 68)
        plot1 = fig.add_subplot(111)
        plot1.plot((1e-3)*InputArray[2::,2], -0.12452*(InputArray[2::,4]-Zero_IDX_I)/ReadResist, color = 'blue' )                       # 3300/26500 = 0.12452   
        plot1.set_xlabel("$t$ in s", fontsize = 13)
        plot1.set_ylabel("$I$ in mA", fontsize = 13, color = 'blue')
        plot1.grid(which='both', linestyle = '--')
        plot1.tick_params(direction = 'in', length=4, width=0.5, colors='k', labelsize = 13)
        plot2 = plot1.twinx()
        plot2.plot((1e-3)*InputArray[2::,2], -0.000249*(InputArray[2::,3]-Zero_IDX_E), color = 'red' )                                  # 6.6/26500 = 0.000249
        plot2.tick_params(direction = 'in', length=4, width=0.5, colors='k', labelsize = 13)
        plot2.set_ylabel("$E$ vs. RE in V", fontsize = 13, color = 'red')
        canvas = FigureCanvasTkAgg(fig, PotentiostatWindow)           # creating the Tkinter canvas containing the Matplotlib figure
        canvas.draw()                                   # Draw the canvas
        canvas.get_tk_widget().place(x = 325, y = 10)   # placing the canvas on the Tkinter window

    
    if __name__ == 'PolArStat_CA_Script':
        ###############################################################################
        # The following part is the main loop which calls the GUI for interfacing with 
        #the Arduino. The Arduino has to contain the firmware before this script works.
        ###############################################################################
    
        PotentiostatWindow = tk.Tk()
        PotentiostatWindow.title("Main Interface for measuring Chronoamperometry with PolArStat")
        PotentiostatWindow.geometry('800x460')
        menu = Menu(PotentiostatWindow)                                               
        PotentiostatWindow.config(menu=menu)
        #=================================================================================
        #=================================================================================
           
        labelTop = tk.Label(PotentiostatWindow, text = "Choose COM Port")
        labelTop.place(x = 25, y = 10)
    
        portsl = FindPorts()
    
        portList = ttk.Combobox(PotentiostatWindow, postcommand=lambda: portList.configure(values=portsl))
        portList.place(x = 140, y = 10, width = 135, height = 19)
        
        Refresh_btn = ttk.Button(PotentiostatWindow, text="Refresh Portlist", command=Portlist_Refresh)   
        Refresh_btn.place(x = 25, y = 35, width = 120, height = 25)
        
        SSer_btn = ttk.Button(PotentiostatWindow, text="Start Serial", command=StartSerial)   
        SSer_btn.place(x = 155, y = 35, width = 120, height = 25)
        
        #=======================================================
        #=======================================================
        #=======================================================
        #   Input for the CVs
        #=======================================================
        #=======================================================
            
        E_1_Label = Label(PotentiostatWindow,text="E1 vs. Ref [V]*")
        E_1_Label.place(x = 25, y = 70)
        E_1_Eingabe = Entry(PotentiostatWindow)
        E_1_Eingabe.insert(END, -0.5) 
        E_1_Eingabe.place(x = 110, y = 70, width = 50, height = 20)
        
        E_2_Label = Label(PotentiostatWindow,text="E2 vs. Ref [V]*")
        E_2_Label.place(x = 25, y = 95)
        E_2_Eingabe = Entry(PotentiostatWindow)
        E_2_Eingabe.insert(END, 0.5) 
        E_2_Eingabe.place(x = 110, y = 95, width = 50, height = 20)
        
        E_3_Label = Label(PotentiostatWindow,text="E3 vs. Ref [V]*")
        E_3_Label.place(x = 25, y = 120)
        E_3_Eingabe = Entry(PotentiostatWindow)
        E_3_Eingabe.insert(END, 0.0) 
        E_3_Eingabe.place(x = 110, y = 120, width = 50, height = 20)
        
        E_4_Label = Label(PotentiostatWindow,text="E4 vs. Ref [V]*")
        E_4_Label.place(x = 25, y = 145)
        E_4_Eingabe = Entry(PotentiostatWindow)
        E_4_Eingabe.insert(END, 0.0) 
        E_4_Eingabe.place(x = 110, y = 145, width = 50, height = 20)
        
        E_5_Label = Label(PotentiostatWindow,text="E5 vs. Ref [V]*")
        E_5_Label.place(x = 25, y = 170)
        E_5_Eingabe = Entry(PotentiostatWindow)
        E_5_Eingabe.insert(END, 0.0) 
        E_5_Eingabe.place(x = 110, y = 170, width = 50, height = 20)
        
        
        t_1_Label = Label(PotentiostatWindow,text="t1 [s]*")
        t_1_Label.place(x = 175, y = 70)
        t_1_Eingabe = Entry(PotentiostatWindow)
        t_1_Eingabe.insert(END, 10) 
        t_1_Eingabe.place(x = 222, y = 70, width = 50, height = 20)
        
        t_2_Label = Label(PotentiostatWindow,text="t2 [s]*")
        t_2_Label.place(x = 175, y = 95)
        t_2_Eingabe = Entry(PotentiostatWindow)
        t_2_Eingabe.insert(END, 10) 
        t_2_Eingabe.place(x = 222, y = 95, width = 50, height = 20)
        
        t_3_Label = Label(PotentiostatWindow,text="t3 [s]*")
        t_3_Label.place(x = 175, y = 120)
        t_3_Eingabe = Entry(PotentiostatWindow)
        t_3_Eingabe.insert(END, 0) 
        t_3_Eingabe.place(x = 222, y = 120, width = 50, height = 20)
        
        t_4_Label = Label(PotentiostatWindow,text="t4 [s]*")
        t_4_Label.place(x = 175, y = 145)
        t_4_Eingabe = Entry(PotentiostatWindow)
        t_4_Eingabe.insert(END, 0) 
        t_4_Eingabe.place(x = 222, y = 145, width = 50, height = 20)
        
        t_5_Label = Label(PotentiostatWindow,text="t5 [s]*")
        t_5_Label.place(x = 175, y = 170)
        t_5_Eingabe = Entry(PotentiostatWindow)
        t_5_Eingabe.insert(END, 0) 
        t_5_Eingabe.place(x = 222, y = 170, width = 50, height = 20)
        
        Repetitions_Label = Label(PotentiostatWindow,text="Repetitions*")
        Repetitions_Label.place(x = 25, y = 215)
        Repetitions_Eingabe = Entry(PotentiostatWindow)
        Repetitions_Eingabe.insert(END, 1)
        Repetitions_Eingabe.place(x = 150, y = 215)
        
        R_read_Label = Label(PotentiostatWindow,text="R read [Ohm]*")
        R_read_Label.place(x = 25, y = 240)
        R_read_Eingabe = Entry(PotentiostatWindow)
        R_read_Eingabe.insert(END, 120)
        R_read_Eingabe.place(x = 150, y = 240)
        
        Exper_Notes_Label = Label(PotentiostatWindow,text="Experimental Notes")
        Exper_Notes_Label.place(x = 25, y = 270)
        Exper_Notes_Eingabe = tk.scrolledtext.ScrolledText(PotentiostatWindow,  wrap = tk.WORD,  font = ("Times New Roman", 9))
        Exper_Notes_Eingabe.place(x = 25, y = 295, width = 250, height = 60)
        
        CVSet_btn = ttk.Button(PotentiostatWindow, text="Send CA inputs", command=Set_CA_Params)   
        CVSet_btn.place(x = 25, y = 370, width = 120, height = 25)
        
        CVGet_btn = ttk.Button(PotentiostatWindow, text="Check CA inputs", command=Get_CA_Params)   
        CVGet_btn.place(x = 155, y = 370, width = 120, height = 25)
        
        CVRun_btn = ttk.Button(PotentiostatWindow, text="Run CA", command=AskSaveFile_AndStart_CA)   
        CVRun_btn.place(x = 25, y = 405, width = 120, height = 50)
        
        CVStop_btn = ttk.Button(PotentiostatWindow, text="Stop CA", command=Stop_CA)   
        CVStop_btn.place(x = 155, y = 405, width = 120, height = 50)
        
        Output_text_Label = Label(PotentiostatWindow,text="Monitor serial output data")
        Output_text_Label.place(x = 325, y = 350)
        Output_text = tk.scrolledtext.ScrolledText(PotentiostatWindow,  wrap = tk.WORD,  font = ("Times New Roman", 9)) 
        Output_text.place(x = 325, y = 370,  width = 450,  height = 85) 
        # Placing cursor in the text area 
        Output_text.focus() 
        
        
        
        if Initiate_Plot == True:
            Plot_Spacer()
            Initiate_Plot = FALSE
        
        
        PotentiostatWindow.after(50, Serial_Looper)     # this command pulls back and forth with the Serial_Looper function
        PotentiostatWindow.mainloop()
        arduino.close()   
    

        
        
#root = Tk()
#root.title("Test")  
#root.geometry('800x460')
#button=Button(root,text="Run",bg = '#9BA9C5', command = PotiScript).place(x = 215, y = 90, width = 60, height = 22)
#button=Button(root,text="Training",bg = '#9BA9C5', command = PotiScript).place(x = 215, y = 117, width = 60, height = 22)
#button=Button(root,text="Help",bg = '#9BA9C5', command = PotiScript).place(    x = 215, y = 144, width = 60, height = 22)

#mainloop()
    