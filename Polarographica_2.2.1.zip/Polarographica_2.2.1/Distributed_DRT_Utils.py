# -*- coding: utf-8 -*-
"""
Created on Wed Feb 16 19:57:58 2022

@author: Tim Tichter

timtic@dtu.dk
timtic@gmx.de
"""

#=======================================================================================================================
#=======================================================================================================================
#=======================================================================================================================
#Author:       Tim Tichter
#Date:         2022.07.28
#Function:     POLAROGRAPHICAS DRT Function which uses either gaussian RBF, Cole-Cole-RBF of no RBF (native)
#=======================================================================================================================
#=======================================================================================================================
#importing all required modules from Python
#=======================================================================================================================
#=======================================================================================================================
from tkinter                           import *
from tkinter.filedialog                import askopenfilename
from tkinter.filedialog                import asksaveasfilename
import numpy as np
import matplotlib
matplotlib.use('TkAgg')
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.backend_bases          import key_press_handler
from matplotlib.figure                 import Figure
from scipy.interpolate                 import interp1d
from scipy.interpolate                 import InterpolatedUnivariateSpline
from scipy.optimize                    import curve_fit
from scipy.optimize                    import nnls
from scipy.linalg                      import toeplitz
from scipy.special                     import kv, iv, gamma
from scipy.integrate                   import quad
from scipy                             import fft, ifft
from scipy.signal                      import hilbert
from cmath                             import *
from math                              import ceil,floor
import mpmath as mp
mp.dps = 25; mp.pretty = True
#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
# Re-import the loading modules from DRT_Transformation_DRT_Tools
from DRT_Transformation_DRT_Tools      import No_Loaded_File_Warner, Open_ImpDRT_File, Get_ImpDRT_Data
#-----------------------------------------------------------------------------

#=======================================================================================================================
#=======================================================================================================================
#define some global variables, functions and warning functions
#=======================================================================================================================
#=======================================================================================================================

global F
global R
global File_Was_Loaded
F = 96485.0
R = 8.314
File_Was_Loaded = 0
def cot(phi):
    return 1.0/tan(phi)
def csc(phi):
    return 1.0/sin(phi)
def coth(x):
    return 1/tanh(x)


##############################################################################################
#  In this step, the Gaussian and Cole-Cole distribution matrices are generated.
#  This is required to put a smoothing into the final fitting step. The Gaussian and
#  Cole-Cole DRTs are normalized - i.e. their integral is equal to one.
##############################################################################################

def build_Gauss(LOGtau, FWHM):
    c = FWHM/2.35482
    X_Gauss = np.zeros((len(LOGtau),len(LOGtau)))
    for m in range(len(LOGtau)):
        for n in range(len(LOGtau)):
            X_Gauss[m,n] = (np.exp(-((LOGtau[m]-LOGtau[n])**2)/(2*c**2)))/(2*np.pi*c**2)**0.5
    return X_Gauss


def build_ColeCole(LOGtau, GAMMA):
    Taus = 2.7182818**LOGtau
    X_ColeCole = np.zeros((len(LOGtau),len(LOGtau)))
    for m in range(len(LOGtau)):
        X_ColeCole[m,::] = (1/(2*np.pi))*np.sin(np.pi*(1-GAMMA))/(np.cosh((GAMMA)*np.log(Taus/Taus[m]))  -  np.cos(np.pi*(1-GAMMA))   )
        #X_ColeCole[m,::] = (1/(2*np.pi))*np.sin(np.pi*(gamma))/(np.cosh((gamma)*np.log(Taus/Taus[m]))  +  np.cos(np.pi*(gamma))   )
    return X_ColeCole
  
         
################################################################################################
#  Here, a set of time constants is generated on the base of the frequencied which are provided
#  with the experimental dataset.
################################################################################################    
    
def make_tau(freq_raw, low_ext, high_ext, resol):
    taumax      = ceil(np.max(np.log10(1./freq_raw))) + high_ext
    taumin      = floor(np.min(np.log10(1./freq_raw)))- np.abs(low_ext)
    tau         = np.logspace(taumin,taumax,resol*len(freq_raw))
    return tau    


################################################################################################
#  Here, the RC Kernel-Matrix is generated. This matrix is the key for computing the DRT later on
################################################################################################    

def build_RC(freq_raw, tau):
    X_RC   = np.zeros((len(freq_raw),len(tau)),dtype=np.complex)
    dlntau = np.log(tau[1]/tau[0])
    for m in range(len(freq_raw)):
        for n in range(len(tau)):
            X_RC[m][n] = dlntau/(1+2j*np.pi*freq_raw[m]*tau[n])
    return X_RC


################################################################################################
#  This function computes the native DRT. This requires regularization. We use Tikhonov-regularization
#  for this purpose. The resulting Matrix-vector equation gives a set of linear equations
#  which are solved by the Lawson-Hansen NNLS (non-negative least-square) solver.
#  Regularization is achieved by adding a linear penalty term (so no derivative penalty).
#  Essentially, we do
#
#  | X_RC | |DRT|  = |Z|
#  | e*U  |          |0|
#  where U is the unity matrix, e the regularization parameter and 0 he zero vector.
#  For the Real part, we take |X_RC.real| and Z.real
#  For the Imaginary part, we take |X_RC.imag| and Z.imag
#  and for the combi-fit, we do
#  | X_RC_re | |DRT|  = |Z_re|
#  | X_RC_im |          |Z_im| 
#  | e*U     |          |0|
################################################################################################ 

def DRT_Native(freq_raw, Z_raw, damp, low_ext, high_ext, resol, DRT_Type):
    tau             = make_tau(freq_raw, low_ext, high_ext, resol)
    dlntau          = np.log(tau[1]/tau[0])
    X_RC_classic    = build_RC(freq_raw, tau)
    X_RC            = X_RC_classic
    if DRT_Type == "real":
        Kernel_Matrix = np.vstack((X_RC.real,damp*np.identity(X_RC.shape[1])))
        gamma_raw     = nnls(Kernel_Matrix, np.concatenate([Z_raw.real,np.zeros(len(tau))]))[0]  
    if DRT_Type == "imag":
        Kernel_Matrix = np.vstack((X_RC.imag,damp*np.identity(X_RC.shape[1])))
        gamma_raw     = nnls(Kernel_Matrix, np.concatenate([Z_raw.imag,np.zeros(len(tau))]))[0]
    if DRT_Type == "comb":
        Kernel_Matrix = np.vstack(np.vstack((X_RC.real,X_RC.imag)),damp*np.identity(X_RC.shape[1])) 
        gamma_raw     = nnls(Kernel_Matrix, np.concatenate([np.concatenate([Z_raw.real,Z_raw.imag]),np.zeros(len(tau))]))[0]
    return np.log10(tau), gamma_raw, Kernel_Matrix, X_RC_classic, dlntau


################################################################################################
#  This function computes the Gaussian DRT. This again requires regularization. We use Tikhonov
#  -regularization for this purpose. The resulting Matrix-vector equation gives a set of linear 
#  equations which are solved by the Lawson-Hansen NNLS (non-negative least-square) solver.
#  Regularization is achieved by adding a linear penalty term (so no derivative penalty).
#  Essentially, we take
#  X_RC_classic  --> The kernel matrix from the classical DRT
#  X_Gauss       --> A Matrix which ntroduces a broadening of each DRT signal according to
#                    a normalized Gauss function (its integral is one).
#  X_RC =  dot(X_RC_classic, X_Gauss) --> The dot product of both matrices. Subsequently, we do
#  ----------------------------------------------------------
#  | X_RC | |DRT|  = |Z|
#  | e*U  |          |0|
#  ----------------------------------------------------------
#  where U is the unity matrix, e the regularization parameter and 0 he zero vector.
#  For the Real part, we take |X_RC.real| and Z.real
#  For the Imaginary part, we take |X_RC.imag| and Z.imag
#  and for the combi-fit, we do
#  | X_RC_re | |DRT|  = |Z_re|
#  | X_RC_im |          |Z_im| 
#  | e*U     |          |0|
################################################################################################ 

def DRT_Gaussian_RBF(freq_raw, Z_raw, damp, low_ext, high_ext, resol, DRT_Type, FWHM):
    tau             = make_tau(freq_raw, low_ext, high_ext, resol)
    dlntau          = np.log(tau[1]/tau[0])
    X_RC_classic    = build_RC(freq_raw, tau)
    X_Gauss         = build_Gauss(np.log(tau), FWHM)
    X_RC            = np.dot(X_RC_classic, X_Gauss)
    if DRT_Type == "real":
        Kernel_Matrix = np.vstack((X_RC.real,damp*np.identity(X_RC.shape[1])))
        gamma_raw     = nnls(Kernel_Matrix, np.concatenate([Z_raw.real,np.zeros(len(tau))]))[0]
    if DRT_Type == "imag":
        Kernel_Matrix = np.vstack((X_RC.imag,damp*np.identity(X_RC.shape[1])))
        gamma_raw     = nnls(Kernel_Matrix, np.concatenate([Z_raw.imag,np.zeros(len(tau))]))[0]
    if DRT_Type == "comb":
        Kernel_Matrix = np.vstack(np.vstack((X_RC.real,X_RC.imag)),damp*np.identity(X_RC.shape[1])) 
        gamma_raw     = nnls(Kernel_Matrix, np.concatenate([np.concatenate([Z_raw.real,Z_raw.imag]),np.zeros(len(tau))]))[0]
    gamma_fine = np.dot(X_Gauss, gamma_raw)
    return np.log10(tau), gamma_raw, gamma_fine, Kernel_Matrix, X_Gauss, X_RC_classic, X_RC, dlntau


###################################################################################################
#  Here, essentially the same is done as for the Gaussian DRT. The difference is that the analytical
#  DRT expression from Cole and Cole [1] is used as radial basis function. 
#  NOTE THAT THIS EXPRESSION IS VALID FOR A CPE OF THE FORM
#
#  Z(\omega)-Z(\infty)/(Z(\omega)-Z(\infty)) = 1/(1 + (i\omega\tau_{0})^{1-\phi} )
#  
#  where \phi is the ideality-parameter of the CPE. We have taken (1-\phi) = \gamma (not to confuse
#  with the DRT-\gamma(\tau))). In this manner, we see that if \gamma = 1, we have an ideal capacitor.
#  and 0 < \gamma <= 1.
#  
#  [1] K. S. Cole, R. H. Cole, Dispersion and Absorption in Dielectrics I. Alternating Current 
#      Characteristics, The Journal of Chemical Physics 9 (1941)295 341{351. doi:10.1063/1.1750906.
####################################################################################################

def DRT_ColeCole_RBF(freq_raw, Z_raw, damp, low_ext, high_ext, resol, DRT_Type, GAMMA_Cole):
    tau             = make_tau(freq_raw, low_ext, high_ext, resol)
    dlntau          = np.log(tau[1]/tau[0])
    X_RC_classic    = build_RC(freq_raw, tau)
    X_ColeCole      = build_ColeCole(np.log(tau), GAMMA_Cole)
    X_RC            = np.dot(X_RC_classic, X_ColeCole)
    if DRT_Type == "real":
        Kernel_Matrix = np.vstack((X_RC.real,damp*np.identity(X_RC.shape[1])))
        gamma_raw     = nnls(Kernel_Matrix, np.concatenate([Z_raw.real,np.zeros(len(tau))]))[0]
    if DRT_Type == "imag":
        Kernel_Matrix = np.vstack((X_RC.imag,damp*np.identity(X_RC.shape[1])))
        gamma_raw     = nnls(Kernel_Matrix, np.concatenate([Z_raw.imag,np.zeros(len(tau))]))[0]
    if DRT_Type == "comb":
        Kernel_Matrix = np.vstack(np.vstack((X_RC.real,X_RC.imag)),damp*np.identity(X_RC.shape[1])) 
        gamma_raw     = nnls(Kernel_Matrix, np.concatenate([np.concatenate([Z_raw.real,Z_raw.imag]),np.zeros(len(tau))]))[0]
    gamma_fine = np.dot(X_ColeCole, gamma_raw)
    return np.log10(tau), gamma_raw, gamma_fine, Kernel_Matrix, X_ColeCole, X_RC_classic, X_RC, dlntau




    




























'''


Freq        = np.logspace(6,-2,100)
omega       = 2*np.pi*Freq
C_D         = 0.01
Resist      = 5
gCPE        = 0.92
Imp         = 1/(1/Resist + ((1j*omega)**gCPE)*C_D)  + 1/(1/(5*Resist) + 1j*omega*C_D)
LOGTAU      = np.log10(Resist*C_D)
GaussWidth  = 0.5
RegPar      = 0.01







#DRT_Native(freq_raw, Z_raw, damp, low_ext, high_ext, resol, DRT_Type)
DRT_Re_Gauss         = DRT_Gaussian_RBF(Freq, Imp, RegPar, 2, 2, 2, "real", FWHM = GaussWidth) 
DRT_Im_Gauss         = DRT_Gaussian_RBF(Freq, Imp, RegPar, 2, 2, 2, "imag", FWHM = GaussWidth) 

DRT_Re_Native        = DRT_Native(Freq, Imp, RegPar, 2, 2, 2, "real") 
DRT_Im_Native        = DRT_Native(Freq, Imp, RegPar, 2, 2, 2, "imag") 

ImpBack_Re_Gauss     = np.dot(DRT_Re_Gauss[5], DRT_Re_Gauss[2])
ImpBack_Im_Gauss     = np.dot(DRT_Im_Gauss[5], DRT_Im_Gauss[2])

ImpBack_Re_Native    = np.dot(DRT_Re_Native[3], DRT_Re_Native[1])
ImpBack_Im_Native    = np.dot(DRT_Im_Native[3], DRT_Im_Native[1])



DRT_Re_ColeCole      = DRT_ColeCole_RBF(Freq, Imp, RegPar, 2, 2, 2, "real", GAMMA_Cole = 0.95) 
DRT_Im_ColeCole      = DRT_ColeCole_RBF(Freq, Imp, RegPar, 2, 2, 2, "imag", GAMMA_Cole = 0.95) 

ImpBack_Re_ColeCole  = np.dot(DRT_Re_ColeCole[5], DRT_Re_ColeCole[2])
ImpBack_Im_ColeCole  = np.dot(DRT_Im_ColeCole[5], DRT_Im_ColeCole[2])









plt.figure(figsize=(12,4), dpi = 80)
plt.subplot(131)
plt.plot(Imp.real,                  -Imp.imag, marker = '.', linestyle = '', color = 'red', label = 'Data')
plt.plot(ImpBack_Re_Native.real,    -ImpBack_Im_Native.imag, marker = '', color = 'magenta', label = 'back native')
plt.plot(ImpBack_Re_Gauss.real,     -ImpBack_Im_Gauss.imag, marker = '', color = 'black', label = 'back Gauss')
plt.plot(ImpBack_Re_ColeCole.real,  -ImpBack_Im_ColeCole.imag, marker = '', color = 'blue', label = 'back Cole')


plt.ylim(-0.5,1.2*np.max(Imp.real))
plt.legend(frameon = False, fontsize = 12)

plt.subplot(132)
#plt.plot(DRT_Re_Gauss[0], DRT_Re_Gauss[1])
plt.plot(DRT_Re_Native[0],   DRT_Re_Native[1],   color = 'magenta', label = 'Re-nat')
plt.plot(DRT_Re_Gauss[0],    DRT_Re_Gauss[2],    color = 'black', label = 'Re-Gau')
plt.plot(DRT_Re_ColeCole[0], DRT_Re_ColeCole[2], color = 'blue', label = 'Re-Cole')
plt.legend(frameon = False, fontsize = 12)


plt.subplot(133)
#plt.plot(DRT_Im_Gauss[0],  DRT_Im_Gauss[1])
plt.plot(DRT_Im_Native[0],    DRT_Im_Native[1],   color = 'magenta', label = 'Im-nat')
plt.plot(DRT_Im_Gauss[0],     DRT_Im_Gauss[2],    color = 'black', label = 'Im-Gau')
plt.plot(DRT_Re_ColeCole[0],  DRT_Re_ColeCole[2], color = 'blue', label = 'Im-Cole')
plt.legend(frameon = False, fontsize = 12)

plt.show()


'''









