# -*- coding: utf-8 -*-
"""
Created on Mon Feb  1 19:58:46 2021

@author: gisel
"""

#==========================================================================================================================
#Load all the required modules
#==========================================================================================================================
import matplotlib.pyplot as plt
import time
import numpy as np
import time
import os
from tkinter                           import *
from tkinter.filedialog                import askopenfilename
from tkinter.filedialog                import asksaveasfilename


#=========================================================================
#GPU ACCELERATED FUNCTIONS
#=========================================================================
#This is a TDMA solver aka the Thomas algorithm. Th e classical sp solver does not work on the GUP which is why I
#wrote this solver for the GPU accelerated computing                                                    #Function decorator to adress the GPU
def Thomas(a,b,c,L):
    cs = np.zeros(len(c))
    Ls = np.zeros(len(L))
    x  = np.zeros(len(L))
    cs[0] = c[0]/b[0]
    Ls[0] = L[0]/b[0]
    for i in range(len(L)-1):
        if i>0:
            cs[i]= c[i]/(b[i] - a[i-1]*cs[i-1])
            Ls[i]= (L[i] - a[i-1]*Ls[i-1])/(b[i] - a[i-1]*cs[i-1])
    Ls[-1] = (L[-1] - a[-1]*Ls[-2])/(b[-1] - a[-1]*cs[-1])
    x[-1] = Ls[-1]
    for i in range(len(L)):
        if i > 0:
            x[-(i+1)] = Ls[-(i+1)] - cs[-(i)]*x[-(i)]
    return x

#This function is the matrixbuilder for the Douglas-Gunn algorithm. It is basically a 1-D Crank Nicolson type of matrix
#which involves any internal boundary conditions from a Starting-Array. It returns three vectors which will be used by the Thomas
#function to solve for the next time-(sub)-iteration
def Matbuilder(Array_Vector, ll):
    lenx       = len(Array_Vector)
    Middle     = (2+2*ll)*np.ones(lenx)
    Middle[0]  = (2+ll)
    Middle[-1] = (2+ll)
    OffDiag    = -ll*np.ones(lenx-1)
    Middle     = Middle*Array_Vector + (Array_Vector-1)**2
    up1        = OffDiag*Array_Vector[0:-1:]
    low1       = OffDiag*Array_Vector[1::]
    return low1,  Middle, up1


def Deriv_3D(stackk, Startt):
    sta                     = np.zeros((len(stackk[::,0,0])+2, len(stackk[0,::,0])+2, len(stackk[0,0,::])+2))
    sta[1:-1:,1:-1:,1:-1:] += -6*stackk
    sta[0:-2:,1:-1:,1:-1:] += stackk[::,::,::]
    sta[2::,1:-1:,1:-1:]   += stackk[::,::,::]
    sta[1:-1:,0:-2:,1:-1:] += stackk[::,::,::]
    sta[1:-1:,2::,1:-1:]   += stackk[::,::,::]
    sta[1:-1:,1:-1:,0:-2:] += stackk[::,::,::]
    sta[1:-1:,1:-1:,2::]   += stackk[::,::,::]
    sta[1:-1:,1:-1:,1:-1:]  = sta[1:-1:,1:-1:,1:-1:]*(Startt-1)**2
    Result                 = np.sum(sta[1:-1:,1:-1:,1:-1:])
    return Result


#This function is basically the heart of the computations of the 3D diffusion stuff. It is the Douglas gunn modification of the
#3D Crank Nicolson algorithm. It is particularly useful, since it splits each and every time step into three substeps and
#therefore involves tridiagonal matrices only. Since it removes the recursive behaviour of the 3D Crank-Nicolson technique
#by splitting each time iteration into 3N^2 steps, which are almost independent of each other, it suggests to utilize
#the GPU instead of the CPU for massive speed up in the computations owing to parallel processing. This is ultra super nice.
#You might use it once your device has a NVIDIA GPU-- see installation of cuda, numba and cudatoolkit.
#@jit(nopython=True)
def DouglasGunn(stack, START, ll):

    Interm_Array    = np.ones_like(stack)
    stack_one_Third = np.ones_like(stack)
    stack_two_Third = np.ones_like(stack)
    stack_complete  = np.ones_like(stack)
    #===========================================================================================================================
    #Timestep 1/3
    #===========================================================================================================================
    Interm_Array[1:-1:,1:-1:,1:-1:] = (ll*(stack[0:-2:,1:-1:,1:-1:] - 10*stack[1:-1:,1:-1:,1:-1:] + stack[2::,1:-1:,1:-1:]
                              + 2*(stack[1:-1:,0:-2:,1:-1:] + stack[1:-1:,2::,1:-1:]
                              + stack[1:-1:,1:-1:,0:-2:]    + stack[1:-1:,1:-1:,2::])) + 2*stack[1:-1:,1:-1:,1:-1:])*START
    #=====================================================================================================
    #SOLVE THE 1/3 STEP
    #=====================================================================================================
    for j in range(len(START[0,::,0])):
        for k in range(len(START[0,0,::])):
            aa,bb,cc                          = Matbuilder(START[::,j,k], ll)
            stack_one_Third[1:-1:,j+1,k+1]    = Thomas(aa,bb,cc, Interm_Array[1:-1:,j+1,k+1])
    stack_one_Third[ 0,1:-1:,1:-1:]           = stack_one_Third[ 1,1:-1:,1:-1:]
    stack_one_Third[-1,1:-1:,1:-1:]           = stack_one_Third[-2,1:-1:,1:-1:]
    stack_one_Third[1:-1:, 0,1:-1:]           = stack_one_Third[1:-1:, 1,1:-1:]
    stack_one_Third[1:-1:,-1,1:-1:]           = stack_one_Third[1:-1:,-2,1:-1:]
    stack_one_Third[1:-1:,1:-1:, 0]           = stack_one_Third[1:-1:,1:-1:, 1]
    stack_one_Third[1:-1:,1:-1:,-1]           = stack_one_Third[1:-1:,1:-1:,-2]
    #===========================================================================================================================
    #Timestep 2/3
    #===========================================================================================================================
    Interm_Array[1:-1:,1:-1:,1:-1:] = (ll*(stack_one_Third[0:-2:,1:-1:,1:-1:] - 2*stack_one_Third[1:-1:,1:-1:,1:-1:]
                            + stack_one_Third[2::,1:-1:,1:-1:]
                            +   stack[0:-2:,1:-1:,1:-1:] - 8*stack[1:-1:,1:-1:,1:-1:] + stack[2::,1:-1:,1:-1:]
                            +   stack[1:-1:,0:-2:,1:-1:] + stack[1:-1:,2::,1:-1:]
                            + 2*stack[1:-1:,1:-1:,0:-2:] + 2*stack[1:-1:,1:-1:,2::]) + 2*stack[1:-1:,1:-1:,1:-1:])*START
    #=====================================================================================================
    #SOLVE THE 2/3 STEP
    #=====================================================================================================
    for i in range(len(START[::,0,0])):
        for k in range(len(START[0,0,::])):
            aa,bb,cc                          = Matbuilder(START[i,::,k], ll)
            stack_two_Third[i+1,1:-1:,k+1]    = Thomas(aa,bb,cc, Interm_Array[i+1,1:-1:,k+1])
    stack_two_Third[ 0,1:-1:,1:-1:]           = stack_two_Third[ 1,1:-1:,1:-1:]
    stack_two_Third[-1,1:-1:,1:-1:]           = stack_two_Third[-2,1:-1:,1:-1:]
    stack_two_Third[1:-1:, 0,1:-1:]           = stack_two_Third[1:-1:, 1,1:-1:]
    stack_two_Third[1:-1:,-1,1:-1:]           = stack_two_Third[1:-1:,-2,1:-1:]
    stack_two_Third[1:-1:,1:-1:, 0]           = stack_two_Third[1:-1:,1:-1:, 1]
    stack_two_Third[1:-1:,1:-1:,-1]           = stack_two_Third[1:-1:,1:-1:,-2]
    #===========================================================================================================================
    #Timestep 3/3
    #===========================================================================================================================
    Interm_Array[1:-1:,1:-1:,1:-1:] = (ll*(stack_one_Third[0:-2:,1:-1:,1:-1:] - 2*stack_one_Third[1:-1:,1:-1:,1:-1:]
                            +   stack_one_Third[2::,1:-1:,1:-1:]
                            +   stack_two_Third[1:-1:,0:-2:,1:-1:] - 2*stack_two_Third[1:-1:,1:-1:,1:-1:]
                            +   stack_two_Third[1:-1:,2::,1:-1:]
                            +   stack[0:-2:,1:-1:,1:-1:] - 6*stack[1:-1:,1:-1:,1:-1:] + stack[2::,1:-1:,1:-1:]
                            +   stack[1:-1:,0:-2:,1:-1:] + stack[1:-1:,2::,1:-1:]
                            +   stack[1:-1:,1:-1:,0:-2:] + stack[1:-1:,1:-1:,2::]) + 2*stack[1:-1:,1:-1:,1:-1:])*START
    for i in range(len(START[::,0,0])):
        for j in range(len(START[0,::,0])):
            aa,bb,cc                         = Matbuilder(START[i,j,::], ll)
            stack_complete[i+1,j+1,1:-1:]    = Thomas(aa,bb,cc, Interm_Array[i+1,j+1,1:-1:])
    stack_complete[ 0,1:-1:,1:-1:]           = stack_complete[ 1,1:-1:,1:-1:]
    stack_complete[-1,1:-1:,1:-1:]           = stack_complete[-2,1:-1:,1:-1:]
    stack_complete[1:-1:, 0,1:-1:]           = stack_complete[1:-1:, 1,1:-1:]
    stack_complete[1:-1:,-1,1:-1:]           = stack_complete[1:-1:,-2,1:-1:]
    stack_complete[1:-1:,1:-1:, 0]           = stack_complete[1:-1:,1:-1:, 1]
    stack_complete[1:-1:,1:-1:,-1]           = stack_complete[1:-1:,1:-1:,-2]
    
    return stack_complete





def GO_DOUGLAS_GUNN():
    #=============================================================================================================================
    #=============================================================================================================================
    #=============================================================================================================================
    #=============================================================================================================================
    print("Compiling Douglas-Gunn related functions")
    dimx, dimy, dimz  = 20,20,20
    
    stack             = np.ones((dimx,dimy,dimz))
    stack[::,::,0]    = np.zeros((dimx,dimy))
    START             = stack
    #print(START)
    ActSites          = Deriv_3D(START, START)
    print ("Number of active sites is:", ActSites)
    dx                = 0.0005
    D                 = 0.000001
    timepoints        = np.arange(0,10,1)
    dt_zero           = 0.001
    dt_max            = 1
    dt_max_arr        = dt_max*np.ones(len(timepoints))
    t_expand          = 0.05
    dt_nonlim         = dt_zero*np.exp(t_expand*timepoints)
    dt_bounded        = dt_nonlim*dt_max_arr/(dt_nonlim + dt_max_arr)
    t                 = np.zeros(len(dt_bounded))
    tt                = 0
    for i in range(len(dt_bounded)):
        tt     += dt_bounded[i]
        t[i]    = tt
    #print ("maximum time is:",max(t))
    #===================================================================
    #Go for Douglas Gunn
    #===================================================================
    ll_Array     = D*dt_bounded/dx**2  #0.5*np.ones(len(dt_bounded))#
    Flux_Array   = np.zeros(len(ll_Array))
    st           = np.zeros((len(stack[::,0,0])+2, len(stack[0,::,0])+2, len(stack[0,0,::])+2))
    st[1:-1:,1:-1:,1:-1:]        = stack
    st[ 0,1:-1:,1:-1:]           = stack[ 0,::,::]
    st[-1,1:-1:,1:-1:]           = stack[-1,::,::]
    st[1:-1:, 0,1:-1:]           = stack[::, 0,::]
    st[1:-1:,-1,1:-1:]           = stack[::,-1,::]
    st[1:-1:,1:-1:, 0]           = stack[::,::, 0]
    st[1:-1:,1:-1:,-1]           = stack[::,::,-1]
    
    time_start = time.perf_counter()
    sttt = DouglasGunn(st, START, ll_Array[0])
    print("Initializing functions on gpu took", time.perf_counter() - time_start, "seconds")
    

    #=========================================================================================
    #=========================================================================================
    #=========================================================================================
    #RE-DEFINE to use the compiled functions
    #=========================================================================================
    #=========================================================================================
    #=========================================================================================
    

    
    Path                 = askopenfilename()
    stack                = np.load(Path)
    START                = stack.copy()
    
    
    #=====================================================================================================================
    #Define grid sizes
    #=====================================================================================================================
    dx                   = 0.0005
    D                    = 0.000001
    timepoints           = np.arange(0,410,1)
    dt_zero              = 0.001
    dt_max               = 2
    dt_max_arr           = dt_max*np.ones(len(timepoints))
    t_expand             = 0.05
    dt_nonlim            = dt_zero*np.exp(t_expand*timepoints)
    dt_bounded           = dt_nonlim*dt_max_arr/(dt_nonlim + dt_max_arr)
    t                    = np.zeros(len(dt_bounded))
    tt                   = 0
    
    for i in range(len(dt_bounded)):
        tt     += dt_bounded[i]
        t[i]    = tt
    #====================================================================================================================
    #Go for Douglas Gunn
    #====================================================================================================================
    ll_Array              = D*dt_bounded/dx**2
    Flux_Array            = np.zeros(len(ll_Array))
    st                    = np.zeros((len(stack[::,0,0])+2, len(stack[0,::,0])+2, len(stack[0,0,::])+2))
    st[1:-1:,1:-1:,1:-1:] = stack
    st[ 0,1:-1:,1:-1:]    = stack[ 0,::,::]
    st[-1,1:-1:,1:-1:]    = stack[-1,::,::]
    st[1:-1:, 0,1:-1:]    = stack[::, 0,::]
    st[1:-1:,-1,1:-1:]    = stack[::,-1,::]
    st[1:-1:,1:-1:, 0]    = stack[::,::, 0]
    st[1:-1:,1:-1:,-1]    = stack[::,::,-1]
    #====================================================================================================================
    #Douglas-Gunn-Main-Loop
    #====================================================================================================================
    print ("maximum time is:",max(t))
    staaart = time.perf_counter()
    
    
    
    for i in range(len(timepoints)):
        start = time.perf_counter()
        if i == 0:
            ActSites  = Deriv_3D(START, START)
            print ("Number of active sites is:", ActSites)
        if i == 2:
            StartCounting = time.perf_counter()
        if i == 12:
            EndCounting = time.perf_counter()
            print("10 steps 3Dderiv Jit took", EndCounting-StartCounting, "s")
        Flux_Array[i] = D*Deriv_3D(st[1:-1:, 1:-1:, 1:-1:], START)/(ActSites*dx)
        st         = DouglasGunn(st, START, ll_Array[i])
        print ("computation time of current full-loop timestep",i, " of ", len(timepoints), ":", "\t", (time.perf_counter()-start), "s")
        
        if i == 0:
            OUTPATH  = asksaveasfilename(title = "Save Your Data",filetypes = (("save as","*.txt"),("all files","*.*")))
        file = open(OUTPATH, "w")
        for j in range(len(t)):
            file.write(str(t[j]))
            file.write("\t")
            file.write(str(Flux_Array[j]/D**0.5))
            file.write("\n")
        file.close()
    
    print ("Total time was", (time.perf_counter()-staaart), "s")
    
    
    #===================================================================================================================
    #Results
    #===================================================================================================================
    print ("maximum time is:",max(t))
    print ("Number of active sites is:", ActSites)
    plt.plot(np.log10(t),np.log10(Flux_Array), color = 'k', linestyle = ':', linewidth = 2.5)
    plt.plot(np.log10(t),np.log10(D**0.5/(t*np.pi)**0.5), color = 'r')
    plt.ylim(-7,-1)
    plt.xlim(-3,3)
    plt.show()
    
    



















