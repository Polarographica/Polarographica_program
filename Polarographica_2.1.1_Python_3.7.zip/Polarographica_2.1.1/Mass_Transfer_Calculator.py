# -*- coding: utf-8 -*-
"""
Created on Tue May 11 11:55:09 2021

@author: gisel
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import InterpolatedUnivariateSpline
from cmath import *
from scipy.optimize import fsolve 
from mpl_toolkits.axes_grid.inset_locator import (inset_axes, InsetPosition, mark_inset)
from tkinter                              import *
from tkinter.filedialog                   import askopenfilename
from tkinter.filedialog                   import asksaveasfilename



def Conv_Func_Calcer():   
    Path_CA       = askopenfilename()
    data3D        = np.loadtxt(Path_CA, delimiter = '\t')
    
    Chrono_t3D    = data3D[::,0]
    Chrono_I3D    = data3D[::,1]
    
    Inter_x       = np.log10(Chrono_t3D)    #   np.logspace(-6, np.log10(Chrono_t3D[-1]), len(Chrono_t3D))
    
    slice_Point_A = 40
    slice_Point_B = 70
    
    Start_x       = np.log10(Chrono_t3D[:slice_Point_A])
    Start_1D      = np.log10(1/(Chrono_t3D[:slice_Point_A]*np.pi)**0.5)
    
    End_x         = np.log10(Chrono_t3D[slice_Point_B:])
    End_3D        = np.log10(Chrono_I3D[slice_Point_B:])
    
    conc_x        = np.concatenate([Start_x , End_x ])
    conc_y        = np.concatenate([Start_1D, End_3D])
    Interpolation = InterpolatedUnivariateSpline(conc_x, conc_y, k=3)
    Inter_y       = Interpolation(Inter_x)
    

    Chrono_t = Inter_x
    Chrono_I = Inter_y
    #plt.plot(Chrono_t, Chrono_I)
    #plt.show()
    
    
    #remove the logarithm
    Chrono_t = 10**Chrono_t
    Chrono_I = 10**Chrono_I
    
    
    BREAK_IT = 0
    tges     = Chrono_t[-2]   #E_Reg/float(ScaRa)
    nt       = int(1*100000)          #100000 points per Volt
    dt       = tges/nt
    t_Resol  = np.arange(dt, tges, dt)
    if Chrono_t[-1] >= tges:
        if Chrono_t[0] != 0:
            I = Chrono_I
            t = Chrono_t
        if Chrono_t[0] == 0:
            I = Chrono_I[1::]
            t = Chrono_t[1::]
        Measured_Interp2 = InterpolatedUnivariateSpline(np.log10(t), I, k=3)
        I_Resol2         = Measured_Interp2(np.log10(t_Resol))
        Measured_Interp3 = InterpolatedUnivariateSpline(t_Resol, I_Resol2, k=3)
        Measured_Interp  = Measured_Interp3
        I_Resol          = Measured_Interp(t_Resol)
        delta_I          = np.zeros(len(I_Resol))
        for i in range(len(I_Resol)-1):
            delta_I[i] = I_Resol[i+1]-I_Resol[i]   
        H = np.zeros(len(I_Resol))
        for i in range(len(I_Resol)-1):  
            if i == 0:
                H[i+1] = 1/I_Resol[0]
            if i != 0:
                H[i+1] = ((1 - np.sum(H[i::-1]*delta_I[:i+1:]))/I_Resol[0]) 
        print ("Convolution Function got calculated")
        #global CV_InterpolationHin
        #global CV_InterpolationBack
        #CV_InterpolationHin  = InterpolatedUnivariateSpline(np.concatenate([[0],(t_Resol[0:-2:]+0.5*dt)]), np.array(H[0:-1]), k=3)
        #CV_InterpolationBack = InterpolatedUnivariateSpline(np.concatenate([[0],(t_Resol[0:-2:]+0.5*dt)]), np.array(H[0:-1]), k=3)
        
        plt.plot((t_Resol[0:-1:2]), 2*(t_Resol[0:-1:2]/np.pi)**0.5, color = 'k', linewidth = 0.5, label = "1D semi-inf. ")
        plt.plot((t_Resol[0:-1:2]),H[0:-1:2] , linestyle=':', linewidth = 2, color = 'k', label = "3D network")
        plt.legend(frameon = False, fontsize = 15, loc='lower right', bbox_to_anchor=(1, 0.12))
        plt.xlabel('$t$' " / s", fontsize=15)
        plt.ylabel('$M(t)$'  "/ s" '$^{0.5}$', fontsize=15)
        plt.tick_params(direction = 'in', length=4, width=0.5, colors='k', labelsize = 15)
       
        
        OUTPATH_MT  = asksaveasfilename(title = "Save Your Data",filetypes = (("save as","*.txt"),("all files","*.*")))
        file = open(OUTPATH_MT, "w")
        for jj in range(len(t_Resol[0:-1:])):
            file.write(str(t_Resol[jj]))
            file.write("\t")
            file.write(str(H[jj]))
            file.write("\n")
        file.close()
        
    else:
        BREAK_IT = 1
        print ("Invalid time domain")
        
        
        
    