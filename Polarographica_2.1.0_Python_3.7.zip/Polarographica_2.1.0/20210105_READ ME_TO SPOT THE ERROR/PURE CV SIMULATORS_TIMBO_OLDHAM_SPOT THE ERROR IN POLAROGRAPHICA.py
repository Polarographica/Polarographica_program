# -*- coding: utf-8 -*-
"""
Created on Tue Jan  5 12:16:44 2021

@author: gisel
"""

import numpy as np
import matplotlib.pyplot as plt
from cmath                             import *
from math                              import ceil,floor
import mpmath as mp
from scipy.interpolate import InterpolatedUnivariateSpline

R = 8.314
F = 96485
T = 298

E_in     = -0.4
E_up     = 0.4
E_fin    = E_in
DA       = 1e-6
DB       = 1e-6
Scanrate = 0.1
kzero    = 0.0001
alpha    = 0.5


def CV_Calculator_Timbo(nu, alphaaa, kzerooo, Df, Db):

    c = 1
    A = 1
    n = 1
    R = 8.314
    T = 298
    F = 96485
    
    Scanrate = nu
    kzero    = kzerooo
    alpha    = alphaaa
    DA       = Df
    DB       = Db
    sigma    = n*F*DA*Scanrate/(R*T)
    
    
    E_span   = 2*E_up - E_in - E_fin
    
    dXi      = 0.01
    Xi_in    = F*E_in/(R*T)
    Xi_up    = F*E_up/(R*T)
    Xi_fin   = F*E_fin/(R*T)
    Xi_forw  = np.arange(Xi_in, Xi_up, dXi)
    Xi_backw = np.arange(Xi_up, Xi_fin, -dXi)
    Xi       = np.concatenate([Xi_forw, Xi_backw])
    Xi_Num   = len(Xi)
    MaxTime  = E_span/Scanrate
    time     = np.linspace(0,MaxTime, Xi_Num)
    kinTerm  = DA**0.5/(kzero*np.exp(alpha*Xi))
    
    Current  = np.zeros(Xi_Num)
    
    ConvFunc      = 2*time**0.5/np.pi**0.5
    DeltaConvFunc = ConvFunc[1::]-ConvFunc[:-1]
    
    for i in range(Xi_Num-1):
        if i == 0:
            Current[i] = n*F*A*c*DA**0.5/(kinTerm[i] + ConvFunc[1]*(1 + (DA/DB)**0.5 *np.exp(-Xi[i]) ) )
        if i > 0:
            ConvListSum = np.sum(Current[:i+1:]*DeltaConvFunc[i::-1])
            Current[i] = (n*F*A*c*DA**0.5 - (1 + (DA/DB)**0.5 *np.exp(-Xi[i]) )*ConvListSum  )/(kinTerm[i] + ConvFunc[1]*(1 + (DA/DB)**0.5 *np.exp(-Xi[i]) ) )
    
    print(np.max(Current[:-1:]/(n*F*A*c*sigma**0.5)))
    
    return Xi[:-1]*R*T/F , Current[:-1]/(n*F*A*c*sigma**0.5)









def CV_Calculator_Oldham(nu, alphaaa, kzerooo, DiffKoeff):
    n     = 1
    F     = 96485
    R     = 8.314
    T     = 298
    A     = 1
    D     = DiffKoeff
    c     = 0.00001
    E_i   = E_in
    E_0   = 0
    kzero = kzerooo
    alpha = alphaaa
    
    t     = np.linspace(0, 4*np.abs(E_i)/nu, 1000)
    dt    = t[1]-t[0]
    Ef    = E_i + nu*t[0:int((len(t)/2)):]
    Eb    = (E_i + nu*t[int((len(t)/2))]) - nu*(t[int((1+len(t)/2))::]-t[int((len(t)/2))])
    E     = np.concatenate((Ef,Eb))
    Kn    = np.exp(n*F*(E-E_0)/(R*T))
    
    F_t   = (4*t**1.5)/(3*(D*np.pi)**0.5)
    I_f   = np.zeros(len(E))
    
    for m in range(len(E)-1):
        if m > 0: 
            #FOR SCHLEIFE VEKTORISIEREN - Funktioniert!!!
            Iconv    = np.sum(I_f[m-1:0:-1]*(F_t[0:m-1] - 2*F_t[1:m:] + F_t[2:m+1]))
            I_f[m]   = (  (n*F*A*c*dt - (1 + 1/Kn[m])*Iconv)/((dt/(kzero*Kn[m]**alpha)) 
                        + F_t[1]*(1 + 1/Kn[m]))  )
            
    #print (np.max(I_f/(n*F*A*c*(D*n*F*nu/(R*T))**0.5)))
    #plt.plot(E[0:-2],I_f[0:-2]/(n*F*A*c*(D*n*F*nu/(R*T))**0.5))   
    #plt.show()   
    
    return E[0:-2], I_f[0:-2]/(n*F*A*c*(D*n*F*nu/(R*T))**0.5) 








def CV_Calculator_Polarographica_rewritten(Scanrate, alpha, kzero, E_in, E_up, E_fin, D_f, D_b):
    p               = 0.0
    Kp              = 1000000000000.0
    Kf              = 0.00000000001
    f               = 0.0
    SSS             = E_in
    SWT             = E_up
    kmax            = 1e23
    kfin            = kzero/kmax
    
    ScaRa           = Scanrate
    delta_Xi        = 0.01
    delta_E         = delta_Xi*R*T/(F)
    Num_of_E_forw   = int((np.abs(SSS)+np.abs(SWT))/delta_E)
    E_i             = np.abs(SWT) - (Num_of_E_forw+1)*delta_E
    sigma           = F*ScaRa/(R*T)
    Xi_i            = -F*np.abs(E_i)/(R*T)   
    Xi_f            = F*(np.abs(SWT))/(R*T)
    Xi_Asym         = F*(E_fin)/(R*T)
    
    Xi_Array_hin    = np.arange(Xi_i,Xi_f,delta_Xi) 
    Xi_Array_back   = np.arange(Xi_f,Xi_Asym-delta_Xi,-delta_Xi) 
    Xi_Array        = np.concatenate([Xi_Array_hin,Xi_Array_back])
    delta_t         = delta_Xi*R*T/(F*ScaRa)
    t_Array_cont    = np.zeros(len(Xi_Array))
    for i in range(len(Xi_Array )):
        t_Array_cont[i] =  i*delta_t
    Exp_Array       = np.exp(-Xi_Array)
    Preced_Array    = np.exp(-p*t_Array_cont)
    Follow_Array    = np.exp(-f*t_Array_cont)
    Kinetik_Array   = D_f**0.5/(kzero*Exp_Array**(-alpha))
    Fin_Kin_p_Array = 1/(1 + kfin*Exp_Array**(-alpha))      #hier mit minus, weil Exp-Array schon umgedreht ist!
    Fin_Kin_s_Array = 1/(1 + kfin*Exp_Array**((1-alpha)))
     
    #-------------------------------------------------------------------------------------------------- 
    #Jetzt CV berechnen
    #--------------------------------------------------------------------------------------------------
    
    global WuFuInt_p
    WuFuInt_p        = np.empty(len(Xi_Array))
    Delta_WuFuInt_p  = np.empty(len(Xi_Array))
    for i in range(len(t_Array_cont)-1):
        WuFuInt_p[i]        = 2*t_Array_cont[i]**0.5/np.pi**0.5
    for i in range(len(t_Array_cont)-2):
        Delta_WuFuInt_p[i]  = WuFuInt_p[i+1] - WuFuInt_p[i]
        
    global WuFuInt_f
    WuFuInt_f        = np.empty(len(Xi_Array))
    Delta_WuFuInt_f  = np.empty(len(Xi_Array))

    for i in range(len(t_Array_cont)-1):
        WuFuInt_f[i]       = 2*t_Array_cont[i]**0.5/np.pi**0.5
    for i in range(len(t_Array_cont)-2):
        Delta_WuFuInt_f[i]  = WuFuInt_f[i+1] - WuFuInt_f[i]
    
    Chi_Array  = np.zeros(len(Xi_Array))

    for i in range(len(Xi_Array)-1):
    
        #MUCH MUCH MUCH FASTER!!!!!!!!!!!!!!!!!!!!! 
        Summandenarray_p_GG   = Delta_WuFuInt_p[i::-1]*Chi_Array[:i+1:]*Preced_Array[i::-1]
        Summandenarray_f_GG   = Delta_WuFuInt_f[i::-1]*Chi_Array[:i+1:]*Follow_Array[i::-1]
        Summandenarray_p      = Delta_WuFuInt_p[i::-1]*Chi_Array[:i+1:]
        Summandenarray_f      = Delta_WuFuInt_f[i::-1]*Chi_Array[:i+1:]
        Chi_Array[i] = (     (Fin_Kin_p_Array[i]*(1/(1+Kp))*(Kp - Kp*np.sum(Summandenarray_p) - np.sum(Summandenarray_p_GG)) 
                              -(Fin_Kin_s_Array[i]*(D_f/D_b)**0.5)*(Exp_Array[i]/(1+Kf))*(np.sum(Summandenarray_f) + Kf*np.sum(Summandenarray_f_GG))  )/
                        (  Kinetik_Array[i] +  Fin_Kin_p_Array[i]*WuFuInt_p[1]+ (Fin_Kin_s_Array[i]*(D_f/D_b)**0.5)*WuFuInt_f[1]*Exp_Array[i])    )

    #-----------------------------------------------------------------------------------------------
    #-----------------------------------------------------------------------------------------------
    global xxx
    global yyy
    xxx = (Xi_Array)
    yyy   = (Chi_Array[::])/sigma**0.5
    
    print(np.max(yyy))
    return xxx*R*T/F, yyy






#======================================================================================================================
#Crosschecking with Polarographica
#======================================================================================================================

def PlanarSemiHin(s):
    return 1/s**0.5

def PlanarSemiBack(s):
    return 1/s**0.5

def cot(phi):
    return 1.0/tan(phi)
def csc(phi):
    return 1.0/sin(phi)
def coth(x):
    return 1/tanh(x)


def TalbotPlanarSemiHin(t,N):
    h = 2*pi/N;
    shift = 0.0;
    ans   = 0.0;
    if t == 0:
        print ("ERROR:   Inverse transform can not be calculated for t=0")
        return ("Error");
    for k in range(0,N):
        theta  = -pi + (k+1./2)*h;
        z      = shift + N/t*(0.5017*theta*cot(0.6407*theta) - 0.6122 + 0.2645j*theta); 
        dz     = N/t*(-0.5017*0.6407*theta*(csc(0.6407*theta)**2)+0.5017*cot(0.6407*theta)+0.2645j);
        ans    = ans + exp(z*t)*(PlanarSemiHin(z))/z*dz;
            
    return ((h/(2j*pi))*ans).real   

def TalbotPlanarSemiBack(t,N):
    h = 2*pi/N;
    shift = 0.0;
    ans   = 0.0;
    if t == 0:
        print ("ERROR:   Inverse transform can not be calculated for t=0")
        return ("Error");
    for k in range(0,N):
        theta  = -pi + (k+1./2)*h;
        z      = shift + N/t*(0.5017*theta*cot(0.6407*theta) - 0.6122 + 0.2645j*theta); 
        dz     = N/t*(-0.5017*0.6407*theta*(csc(0.6407*theta)**2)+0.5017*cot(0.6407*theta)+0.2645j);
        ans    = ans + exp(z*t)*(PlanarSemiBack(z))/z*dz;
            
    return ((h/(2j*pi))*ans).real   



def model_a_ConvolutionInverter():
    #--------------------------------------------------------------------------------------------
    t_Array                      = np.logspace(-8,5,300)
    ft_Array_PlanarSemiHin       = np.empty(len(t_Array)) 
    ft_Array_PlanarSemiBack      = np.empty(len(t_Array)) 
    for i in range(len(t_Array)):
        ft_Array_PlanarSemiHin[i]     = TalbotPlanarSemiHin(float(t_Array[i]),24)
        ft_Array_PlanarSemiBack[i]    = TalbotPlanarSemiBack(float(t_Array[i]),24)
    global CV_InterpolationHin
    CV_InterpolationHin = InterpolatedUnivariateSpline(t_Array,ft_Array_PlanarSemiHin, k=3)
    global CV_InterpolationBack
    CV_InterpolationBack = InterpolatedUnivariateSpline(t_Array,ft_Array_PlanarSemiBack, k=3)
    
    


def CV_Calculator_Polarographica_Native(Scanrate, alpha, kzero, E_in, E_up, E_fin, D_f, D_b):
#def CV_Calculator():
    
    Go = model_a_ConvolutionInverter()
    p               = 0.0
    Kp              = 1000000000000.0
    Kf              = 0.00000000001
    f               = 0.0
    kmax            = 1000000000000000000000000.0
    kfin            = kzero/kmax
    SSS             = E_in
    SWT             = E_up
    ScaRa           = Scanrate
    delta_Xi        = 0.01
    delta_E         = delta_Xi*R*T/(F)
    Num_of_E_forw   = int((np.abs(SSS)+np.abs(SWT))/delta_E)
    E_i             = np.abs(SWT) - (Num_of_E_forw+1)*delta_E
    sigma           = F*ScaRa/(R*T)
    Xi_i            = -F*np.abs(E_i)/(R*T)   
    Xi_f            = F*(np.abs(SWT))/(R*T)
    Xi_Asym         = F*(E_fin)/(R*T)
    Xi_Array_hin    = np.arange(Xi_i,Xi_f,delta_Xi) 
    Xi_Array_back   = np.arange(Xi_f,Xi_Asym-delta_Xi,-delta_Xi) 
    Xi_Array        = np.concatenate([Xi_Array_hin,Xi_Array_back])
    delta_t         = delta_Xi*R*T/(F*ScaRa)
    t_Array_cont    = np.zeros(len(Xi_Array))
    for i in range(len(Xi_Array )):
        t_Array_cont[i] =  i*delta_t
    Exp_Array       = np.exp(-Xi_Array)
    Preced_Array    = np.exp(-p*t_Array_cont)
    Follow_Array    = np.exp(-f*t_Array_cont)
    Kinetik_Array   = D_f**0.5/(kzero*Exp_Array**(-alpha))
    Fin_Kin_p_Array = 1/(1 + kfin*Exp_Array**(-alpha))      #hier mit minus, weil Exp-Array schon umgedreht ist!
    Fin_Kin_s_Array = 1/(1 + kfin*Exp_Array**((1-alpha)))
   
    #-------------------------------------------------------------------------------------------------- 
    #Jetzt CV berechnen
    #--------------------------------------------------------------------------------------------------
    global WuFuInt_p
    WuFuInt_p        = np.empty(len(Xi_Array))
    Delta_WuFuInt_p  = np.empty(len(Xi_Array))
    for i in range(len(t_Array_cont)-1):
        #WuFuInt_p[i]        = np.pi**0.5 *CV_InterpolationHin(t_Array_cont[i])   #Error in original verion
        WuFuInt_p[i]        = CV_InterpolationHin(t_Array_cont[i])                #corrected version
    for i in range(len(t_Array_cont)-2):
        Delta_WuFuInt_p[i]  = WuFuInt_p[i+1] - WuFuInt_p[i]
        
    global WuFuInt_f
    WuFuInt_f        = np.empty(len(Xi_Array))
    Delta_WuFuInt_f  = np.empty(len(Xi_Array))

    for i in range(len(t_Array_cont)-1):
        #WuFuInt_f[i]       = np.pi**0.5 *CV_InterpolationBack(t_Array_cont[i])       #Error in original verion
        WuFuInt_f[i]       = CV_InterpolationBack(t_Array_cont[i])                    #corrected version
    for i in range(len(t_Array_cont)-2):
        Delta_WuFuInt_f[i]  = WuFuInt_f[i+1] - WuFuInt_f[i]
    
    Chi_Array  = np.zeros(len(Xi_Array))

    for i in range(len(Xi_Array)-1):
    
        #MUCH MUCH MUCH FASTER!!!!!!!!!!!!!!!!!!!!! 
        Summandenarray_p_GG   = Delta_WuFuInt_p[i::-1]*Chi_Array[:i+1:]*Preced_Array[i::-1]
        Summandenarray_f_GG   = Delta_WuFuInt_f[i::-1]*Chi_Array[:i+1:]*Follow_Array[i::-1]
        Summandenarray_p      = Delta_WuFuInt_p[i::-1]*Chi_Array[:i+1:]
        Summandenarray_f      = Delta_WuFuInt_f[i::-1]*Chi_Array[:i+1:]
    


        Chi_Array[i] = (Fin_Kin_p_Array[i]*(1/(1+Kp))*(Kp - Kp*np.sum(Summandenarray_p) - np.sum(Summandenarray_p_GG)) -(Fin_Kin_s_Array[i]*(D_f/D_b)**0.5)*(Exp_Array[i]/(1+Kf))*(np.sum(Summandenarray_f) + Kf*np.sum(Summandenarray_f_GG))  )/(  Kinetik_Array[i] +  Fin_Kin_p_Array[i]*WuFuInt_p[1]+ (Fin_Kin_s_Array[i]*(D_f/D_b)**0.5)*WuFuInt_f[1]*Exp_Array[i])

    #-----------------------------------------------------------------------------------------------
    #-----------------------------------------------------------------------------------------------
    global xxx
    global yyy
    xxx = (Xi_Array)*R*T/F
    #yyy   = np.pi**0.5*(Chi_Array[::])/sigma**0.5                       #Error in original verion
    yyy   = (Chi_Array[::])/sigma**0.5                                   #corrected version                    
    
    return xxx, yyy
     





RESULT_PG_NATIVE = CV_Calculator_Polarographica_Native(Scanrate = Scanrate, alpha = alpha, kzero = kzero, E_in = E_in, E_up = E_up, E_fin = E_fin, D_f = DA, D_b = DB)

Result = CV_Calculator_Polarographica_rewritten(Scanrate = Scanrate, alpha = alpha, kzero = kzero, E_in = E_in, E_up = E_up, E_fin = E_fin, D_f = DA, D_b = DB)

CVOLDHAM   = CV_Calculator_Oldham(nu = Scanrate, alphaaa = alpha, kzerooo = kzero, DiffKoeff = DA) 
CVOLDHAM_E = CVOLDHAM[0]
CVOLDHAM_I = CVOLDHAM[1]

CVTIMBO   = CV_Calculator_Timbo(nu = Scanrate, alphaaa = alpha, kzerooo = kzero, Df = DA, Db = DB) 
CVTIMBO_E = CVTIMBO[0]
CVTIMBO_I = CVTIMBO[1]


plt.plot(Result[0][1:-2:], Result[1][1:-2:], color = 'blue', label = "Polarographica rewritten analytical")
plt.plot(CVTIMBO_E, CVTIMBO_I, color = 'red', label = "Timbo-style")
plt.plot(CVOLDHAM_E, CVOLDHAM_I, color = 'black', linestyle = ':', linewidth = 2, label = "Oldham-style")
plt.plot(RESULT_PG_NATIVE[0][1:-2:], RESULT_PG_NATIVE[1][1:-2:], linestyle = ':', linewidth = 3, color = 'orange', label = "Polarographica native Talbot")

plt.legend()
plt.show()


    
print("done")
    
    