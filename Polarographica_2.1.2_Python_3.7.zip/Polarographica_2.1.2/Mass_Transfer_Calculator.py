# -*- coding: utf-8 -*-
"""
Created on Tue May 11 11:55:09 2021

@author: gisel
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import InterpolatedUnivariateSpline
from cmath import *
from scipy.optimize import fsolve 
from mpl_toolkits.axes_grid.inset_locator import (inset_axes, InsetPosition, mark_inset)
from tkinter                              import *
from tkinter.filedialog                   import askopenfilename
from tkinter.filedialog                   import asksaveasfilename



def Load_Computed_CA():
    Path_CA       = askopenfilename()
    data3D        = np.loadtxt(Path_CA, delimiter = '\t')
    Chrono_t3D    = data3D[::,0]
    Chrono_I3D    = data3D[::,1]
    x_Compare     = np.log10(np.logspace(-4, np.log10(Chrono_t3D[-1]), len(Chrono_t3D)))
    Cutoff_Definer(x_loaded = Chrono_t3D , y_loaded = Chrono_I3D)
    plt.figure(figsize = (5,5), dpi = 100)
    plt.plot(np.log10(Chrono_t3D), np.log10(Chrono_I3D), color = 'black', label = 'Loaded Data', linestyle = ':')
    plt.plot(x_Compare, np.log10(1/((10**x_Compare)*np.pi)**0.5), color = 'black', label = 'Analytical', linestyle = '-', linewidth = 0.5)
    plt.show()
    

def Cutoff_Definer(x_loaded, y_loaded):
    Fenster = Toplevel()                                                         
    Fenster.title("Cutoff Definer")                         
    Fenster.geometry("300x200")                                            
    LowCutoff_label      = Label(Fenster,text= u'Low-Cutoff')
    LowCutoff_label.place(x = 20, y = 20)
    LowCutoff_Eingabe    = Entry(Fenster)  
    LowCutoff_Eingabe.insert(END, -0.5)                                             
    LowCutoff_Eingabe.place(x = 150, y = 20)
    HighCutoff_label       = Label(Fenster,text= r'High-Cutoff')
    HighCutoff_label.place(x =20, y = 45)
    HighCutoff_Eingabe     = Entry(Fenster)
    HighCutoff_Eingabe.insert(END, 0.5) 
    HighCutoff_Eingabe.place(x = 150, y = 45)
    NumOfTimeIncr_label    = Label(Fenster,text= r'Num. of dt in conv')
    NumOfTimeIncr_label.place(x =20, y = 70)
    NumOfTimeIncr_Eingabe     = Entry(Fenster)
    NumOfTimeIncr_Eingabe.insert(END, 100000) 
    NumOfTimeIncr_Eingabe.place(x = 150, y = 70)
    def Next():
        LowCutoff     = (float(LowCutoff_Eingabe.get()))
        HighCutoff    = (float(HighCutoff_Eingabe.get()))
        NumOfTimeIncr = (int(NumOfTimeIncr_Eingabe.get()))
        Fenster.destroy()
        Conv_Func_Calcer(x_loaded, y_loaded, LowCutoff, HighCutoff, NumOfTimeIncr)
        
    Next = Button(Fenster, text="Next",command=Next)
    Next.place(x = 150, y = 95, width = 60, height = 22)
    



def Conv_Func_Calcer(x_loaded, y_loaded, LowCutoff, HighCutoff, NumOfTimeIncr):   
    Chrono_t3D    = x_loaded
    Chrono_I3D    = y_loaded
    Inter_x       = np.log10(np.logspace(-4, np.log10(Chrono_t3D[-1]), len(Chrono_t3D)))
    slice_Point_A = ((np.log10(x_loaded)-LowCutoff)**2).argmin()
    slice_Point_B = ((np.log10(x_loaded)-HighCutoff)**2).argmin()
    Start_x       = Inter_x[:slice_Point_A]
    Start_1D      = np.log10(1/((10**Inter_x[:slice_Point_A])*np.pi)**0.5)
    End_x         = np.log10(Chrono_t3D[slice_Point_B:])
    End_3D        = np.log10(Chrono_I3D[slice_Point_B:])
    conc_x        = np.concatenate([Start_x , End_x ])
    conc_y        = np.concatenate([Start_1D, End_3D])
    Interpolation = InterpolatedUnivariateSpline(conc_x, conc_y, k=3)
    Inter_y       = Interpolation(Inter_x)
    Chrono_t      = 10**Inter_x
    Chrono_I      = 10**Inter_y
    tges     = Chrono_t[-2]  
    dt       = tges/float(NumOfTimeIncr)
    t_Resol  = np.arange(dt, tges, dt)
    if Chrono_t[-1] >= tges:
        if Chrono_t[0] != 0:
            I = Chrono_I
            t = Chrono_t
        if Chrono_t[0] == 0:
            I = Chrono_I[1::]
            t = Chrono_t[1::]
        Measured_Interp2 = InterpolatedUnivariateSpline(np.log10(t), I, k=3)
        I_Resol2         = Measured_Interp2(np.log10(t_Resol))
        Measured_Interp  = InterpolatedUnivariateSpline(t_Resol, I_Resol2, k=3)
        I_Resol          = Measured_Interp(t_Resol)
        delta_I          = np.zeros(len(I_Resol))
        for i in range(len(I_Resol)-1):
            delta_I[i] = I_Resol[i+1]-I_Resol[i]   
        H = np.zeros(len(I_Resol))
        for i in range(len(I_Resol)-1):  
            if i == 0:
                H[i+1] = 1/I_Resol[0]
            if i != 0:
                H[i+1] = ((1 - np.sum(H[i::-1]*delta_I[:i+1:]))/I_Resol[0]) 
        print ("Convolution Function got calculated")
        
  
        #================================================
        #                  Saving
        #================================================
        OUTPATH_MT  = asksaveasfilename(title = "Save Your Data",filetypes = (("save as","*.txt"),("all files","*.*")))
        file = open(OUTPATH_MT, "w")
        for jj in range(len(t_Resol[0:-1:])):
            file.write(str(t_Resol[jj]))
            file.write("\t")
            file.write(str(H[jj]))
            file.write("\n")
        file.close()
        
        #================================================
        #                  PLOTTING
        #================================================
        plt.figure(figsize = (10,5), dpi = 100)
        plt.subplot(121)
        plt.plot(np.log10(Chrono_t), np.log10(Chrono_I), color = 'black', label = 'Interpol', linestyle = '--')
        plt.plot(np.log10(Chrono_t3D), np.log10(Chrono_I3D), color = 'black', label = 'Numerical', linestyle = ':')
        plt.plot(np.log10(Chrono_t), np.log10(1/(Chrono_t*np.pi)**0.5), color = 'black', label = 'Analytical', linestyle = '-', linewidth = 0.5)
        plt.axvline(np.log10(Chrono_t3D[slice_Point_A]), color = 'black', linewidth = 0.5, linestyle = ':')
        plt.axvline(np.log10(Chrono_t3D[slice_Point_B]), color = 'black', linewidth = 0.5, linestyle = ':')
        plt.legend(frameon = False, fontsize = 15)
             
        plt.subplot(122)
        plt.plot((t_Resol[0:-1:2]), 2*(t_Resol[0:-1:2]/np.pi)**0.5, color = 'k', linewidth = 0.5, label = "1D semi-inf. ")
        plt.plot((t_Resol[0:-1:2]),H[0:-1:2] , linestyle=':', linewidth = 2, color = 'k', label = "3D network")
        plt.legend(frameon = False, fontsize = 15, loc='lower right', bbox_to_anchor=(1, 0.12))
        plt.xlabel('$t$' " / s", fontsize=15)
        plt.ylabel('$M(t)$'  "/ s" '$^{0.5}$', fontsize=15)
        plt.tick_params(direction = 'in', length=4, width=0.5, colors='k', labelsize = 15)
        plt.show()

        
        
        
    